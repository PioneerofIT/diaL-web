<template>
    <body>
        <div class="container" style= "text-align: left; width: auto; height: auto;">
            <div>
                <iframe src="http://52.36.71.154:3000/d-solo/ENk1jS84k/test?orgId=1&refresh=5s&from=1694573117845&to=1694594717845&panelId=12" width="50%" height="50%" frameborder="0"></iframe>
                <iframe src="http://52.36.71.154:3000/d-solo/ENk1jS84k/test?orgId=1&refresh=5s&panelId=13" width="50%" height="50%" frameborder="0"></iframe>
            </div>
            <div>      
                <iframe src="http://52.36.71.154:3000/d-solo/ENk1jS84k/test?orgId=1&refresh=5s&panelId=17" width="50%" height="50%" frameborder="0"></iframe>
                <iframe src="http://52.36.71.154:3000/d-solo/ENk1jS84k/test?orgId=1&refresh=5s&panelId=14" width="50%" height="150" frameborder="0"></iframe>
            </div>
            <div>
                <iframe src="http://52.36.71.154:3000/d-solo/ENk1jS84k/test?orgId=1&refresh=5s&panelId=16" width="50%" height="50%" frameborder="0"></iframe>
                <iframe src="http://52.36.71.154:3000/d-solo/ENk1jS84k/test?orgId=1&refresh=5s&panelId=15" width="50%" height="50%" frameborder="0"></iframe>  
            </div>
        </div>
    </body>
</template>
  
  <style scoped>
    .sensor-page{
        height: 400px;
        margin: 15px;
        padding: 10px;
        border-radius: 5px;
        background-color: 181B1F;
    }

    .weather-info {
  margin: 3%;
  background-color: #181B1F; /* 배경색 설정 */
  border-radius: 3px;
  box-shadow: -6px -6px 5px rgba(0, 0, 0, 0.3);
  color: white;

  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  height: 100%;
  padding: 1%; 
}

.container {
    background-color: #181B1F; /* 배경색 설정 */
    border-radius: 30px;
    box-shadow: -6px -6px 5px rgba(228, 226, 226, 0.8), 6px 6px 5px rgba(0,0,0,0.2);
    width: 100%;
    height: 100%;
    margin: 0 auto; /* 수평 가운데 정렬을 위한 margin 추가 */
    padding: 5% 5% 5% 5%;
    display: flex;
    flex-direction: column;
    justify-content: center; /* 수직 가운데 정렬을 위한 justify-content 추가 */
  }
  </style>
  
  
  
  
  