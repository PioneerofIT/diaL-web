<template>
        <div class="container" style= "text-align: center; width: auto; height: auto;">
            <iframe src="http://52.36.71.154:3000/d-solo/ENk1jS84k/test?orgId=1&panelId=10" width="100%" height="400px" frameborder="0"></iframe>
        </div>
  </template>
  
  <style scoped>
.container {
    background-color: #181B1F; /* 배경색 설정 */
    border-radius: 30px;
    box-shadow: -6px -6px 5px rgba(228, 226, 226, 0.8), 6px 6px 5px rgba(0,0,0,0.2);
    width: 100%;
    height: 100%;
    margin: 0 auto; /* 수평 가운데 정렬을 위한 margin 추가 */
    padding: 5%;
    display: flex;
    flex-direction: column;
    justify-content: center; /* 수직 가운데 정렬을 위한 justify-content 추가 */
  }
  </style>
  